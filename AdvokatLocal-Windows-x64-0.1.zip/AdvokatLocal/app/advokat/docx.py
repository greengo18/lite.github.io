"""Conservative OOXML reader; never opens external relationships or embedded objects."""
from __future__ import annotations

from dataclasses import dataclass, field
from io import BytesIO
import re
import posixpath
from zipfile import ZipFile, ZIP_DEFLATED, BadZipFile

from lxml import etree as ET

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'
NS = {'w': W}
XML_SPACE = '{http://www.w3.org/XML/1998/namespace}space'
TEXT_PART = re.compile(r'word/(document|header\d+|footer\d+|footnotes|endnotes)\.xml$')
ALLOWED = re.compile(r'(\[Content_Types\]\.xml|_rels/\.rels|docProps/(core|app|custom)\.xml|docProps/thumbnail\.(jpeg|jpg|png)|customXml/(item\d+\.xml|itemProps\d+\.xml|_rels/item\d+\.xml\.rels)|word/(document|header\d+|footer\d+|footnotes|endnotes|styles|stylesWithEffects|settings|webSettings|fontTable|numbering)\.xml|word/theme/theme\d+\.xml|word/_rels/[a-zA-Z0-9]+\.xml\.rels)$')
DANGEROUS = {'drawing', 'pict', 'object', 'altChunk', 'subDoc', 'txbxContent',
             'fldSimple', 'fldChar', 'instrText', 'del', 'ins', 'moveFrom', 'moveTo',
             'commentRangeStart', 'commentReference', 'vanish', 'webHidden', 'specVanish',
             'sdt', 'customXml', 'dataBinding', 'sym', 'contentPart'}
TEXT_NAMESPACES = {W}


class DocumentError(ValueError):
    pass


def xml(data: bytes):
    parser = ET.XMLParser(resolve_entities=False, no_network=True, load_dtd=False,
                          huge_tree=False, remove_blank_text=False,
                          remove_comments=True, remove_pis=True)
    root = ET.fromstring(data, parser)
    if root.getroottree().docinfo.doctype:
        raise DocumentError('XML с DTD не поддерживается.')
    return root


def dump(root) -> bytes:
    return ET.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)


@dataclass
class Paragraph:
    part: str
    index: int
    text: str
    nodes: list = field(repr=False)


class Docx:
    def __init__(self, data: bytes):
        self.original = data
        self.entries: dict[str, bytes] = {}
        self.roots: dict = {}
        self.paragraphs: list[Paragraph] = []
        self.blocks: list[str] = []
        if len(data) > 40 * 1024 * 1024:
            raise DocumentError('Файл больше 40 МБ. Первая версия его не обрабатывает.')
        try:
            with ZipFile(BytesIO(data)) as z:
                infos = z.infolist()
                if len(infos) > 2000 or sum(i.file_size for i in infos) > 80 * 1024 * 1024:
                    raise DocumentError('Слишком большой распакованный документ.')
                for i in infos:
                    if i.is_dir():
                        continue
                    if i.filename in self.entries or '..' in i.filename.split('/') or i.filename.startswith('/'):
                        raise DocumentError('Некорректная структура DOCX.')
                    self.entries[i.filename] = z.read(i)
        except (BadZipFile, RuntimeError, OSError) as e:
            raise DocumentError('Не удалось прочитать DOCX; возможно, он зашифрован или поврежден.') from e
        if 'word/document.xml' not in self.entries or '[Content_Types].xml' not in self.entries:
            raise DocumentError('Это не поддерживаемый документ Word DOCX.')
        for name, payload in self.entries.items():
            if not ALLOWED.fullmatch(name):
                self.blocks.append(f'Неподдерживаемая часть: {name}')
                continue
            if name.startswith('docProps/thumbnail.'):
                # Never decode a thumbnail; strip its bytes from the export.
                continue
            try:
                root = xml(payload)
            except (ET.XMLSyntaxError, DocumentError) as e:
                raise DocumentError('Поврежденный или неподдерживаемый XML в DOCX.') from e
            self.roots[name] = root
            if name.endswith('.rels'):
                for rel in root:
                    target = rel.get('Target', '')
                    if rel.get('TargetMode', '').lower() == 'external' or re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', target) or target.startswith('//'):
                        self.blocks.append('Внешняя ссылка или подключенный шаблон: требуется отдельная обработка.')
                    else:
                        base = '' if name == '_rels/.rels' else name.split('/_rels/')[0]
                        resolved = posixpath.normpath(posixpath.join(base, target)) if not target.startswith('/') else target[1:]
                        if resolved not in self.entries:
                            self.blocks.append('Ссылка на отсутствующую или неподдерживаемую часть документа.')
            if name.startswith('word/'):
                for el in root.iter():
                    if not isinstance(el.tag, str):
                        continue
                    q = ET.QName(el)
                    if q.namespace == W and (q.localname in DANGEROUS or q.localname.endswith('Change')):
                        self.blocks.append(f'Непроверенный элемент Word: {q.localname}')
                    if q.localname in {'docVars', 'attachedTemplate', 'mailMerge', 'odso', 'hyperlink', 'bookmarkStart'}:
                        self.blocks.append(f'Служебные данные или ссылка: {q.localname}')
                    if TEXT_PART.fullmatch(name):
                        if q.namespace not in TEXT_NAMESPACES:
                            self.blocks.append('Неподдерживаемое расширение XML в текстовой части.')
                        if el.text and el.text.strip() and el.tag != f'{{{W}}}t':
                            self.blocks.append('Текст в неподдерживаемом элементе документа.')
                        if el.tail and el.tail.strip():
                            self.blocks.append('Текст вне поддерживаемого текстового элемента.')
                if TEXT_PART.fullmatch(name):
                    root_paragraphs = root.findall('.//w:p', NS)
                    for index, p in enumerate(root_paragraphs):
                        nodes = list(p.iter(f'{{{W}}}t'))
                        chunks = []
                        for n in p.iter():
                            if n.tag == f'{{{W}}}t':
                                chunks.append(n.text or '')
                            elif n.tag in {f'{{{W}}}tab', f'{{{W}}}br', f'{{{W}}}cr'}:
                                # Preserve these as boundary sentinels, not editable text.
                                chunks.append('\t' if n.tag.endswith('tab') else '\n')
                        text = ''.join(chunks)
                        self.paragraphs.append(Paragraph(name, index, text, nodes))
                    covered = {n for p in self.paragraphs if p.part == name for n in p.nodes}
                    if any(n not in covered for n in root.iter(f'{{{W}}}t')):
                        self.blocks.append('Текст вне поддерживаемого абзаца.')
        # Require a genuine non-macro main document content type.
        ct = self.roots['[Content_Types].xml']
        main_types = [el.get('ContentType') for el in ct if el.get('PartName') == '/word/document.xml']
        if main_types != ['application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml']:
            self.blocks.append('Необычный тип основного документа (в том числе DOCM) не поддерживается.')
        self.blocks = list(dict.fromkeys(self.blocks))

    def render(self, replacements: dict[tuple[str, int], list[tuple[int, int, str]]]) -> bytes:
        if self.blocks:
            raise DocumentError('Экспорт заблокирован: документ содержит непроверенные части.')
        # Always regenerate from immutable input, never from previously transformed XML.
        copy = Docx(self.original)
        for p in copy.paragraphs:
            edits = replacements.get((p.part, p.index), [])
            if not edits:
                continue
            # Map each visible character to an OOXML node; tab/line-break characters
            # remain structural nodes and may not be removed by a replacement.
            root_p = copy.roots[p.part].findall('.//w:p', NS)[p.index]
            mapping = []
            for n in root_p.iter():
                if n.tag == f'{{{W}}}t':
                    mapping.extend((n, i) for i in range(len(n.text or '')))
                elif n.tag in {f'{{{W}}}tab', f'{{{W}}}br', f'{{{W}}}cr'}:
                    mapping.append(None)
            previous = len(p.text)
            for start, end, token in sorted(edits, reverse=True):
                if not 0 <= start < end <= previous or any(x is None for x in mapping[start:end]):
                    raise DocumentError('Замены перекрываются или пересекают разрыв строки/табуляцию.')
                previous = start
                first, offset = mapping[start]
                last, last_offset = mapping[end - 1]
                if first is last:
                    first.text = (first.text or '')[:offset] + token + (first.text or '')[last_offset + 1:]
                else:
                    first.text = (first.text or '')[:offset] + token
                    active = False
                    for n in p.nodes:
                        if n is first:
                            active = True
                        elif n is last:
                            n.text = (n.text or '')[last_offset + 1:]
                            break
                        elif active:
                            n.text = ''
                first.set(XML_SPACE, 'preserve')
        # Strip metadata from the external copy. Original package bytes are in encrypted vault.
        for name in list(copy.entries):
            if name.startswith(('docProps/', 'customXml/')):
                del copy.entries[name]
        for name, root in copy.roots.items():
            if name.endswith('.rels'):
                for el in list(root):
                    if '/metadata/' in el.get('Type', '') or el.get('Type', '').endswith(('/extended-properties', '/custom-properties', '/thumbnail', '/customXml', '/customXmlProps')):
                        root.remove(el)
            if name == '[Content_Types].xml':
                for el in list(root):
                    if el.get('PartName', '').startswith(('/docProps/', '/customXml/')):
                        root.remove(el)
            # rsid and author attributes can identify the editing environment.
            if name.startswith('word/'):
                for el in root.iter():
                    if not isinstance(el.tag, str):
                        continue
                    for attr in list(el.attrib):
                        if ET.QName(attr).localname.startswith('rsid') or ET.QName(attr).localname in {'author', 'initials'}:
                            del el.attrib[attr]
                    if el.tag == f'{{{W}}}rsids':
                        el.getparent().remove(el)
            if name in copy.entries:
                copy.entries[name] = dump(root)
        output = BytesIO()
        with ZipFile(output, 'w', ZIP_DEFLATED) as z:
            for name, payload in copy.entries.items():
                z.writestr(name, payload)
        result = output.getvalue()
        check = Docx(result)
        if check.blocks or any(n.startswith('docProps/') for n in check.entries):
            raise DocumentError('Итоговая проверка структуры не пройдена.')
        return result
