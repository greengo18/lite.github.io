"""Local document review. No network access is used by this application."""

__version__ = "0.1.0"
