"""Review/export orchestration. Vault is committed before any external copy is written."""
from __future__ import annotations

import base64
import re
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import uuid

from lxml import etree as ET

from .detect import Finding, HARD, detect
from .docx import Docx, DocumentError
from .vault import Vault, VaultError, atomic_write, digest, now


class Session:
    def __init__(self, source: Path):
        self.path = Path(source).resolve()
        if self.path.suffix.lower() != '.docx':
            raise DocumentError('Первая версия принимает только DOCX. DOC, PDF и сканы пока не поддерживаются.')
        if self.path.stat().st_size > 40 * 1024 * 1024:
            raise DocumentError('Файл больше 40 МБ.')
        self.doc = Docx(self.path.read_bytes())
        self.findings = detect(self.doc.paragraphs)
        self.blocks = list(self.doc.blocks)
        if any(HARD.search(p.text) for p in self.doc.paragraphs):
            self.blocks.append('Признаки особо охраняемых сведений. Экспорт в этой версии заблокирован; подготовьте другой документ.')
        if any('КОНФИДЕНЦИАЛЬНО: ВОССТАНОВЛЕННЫЕ ДАННЫЕ' in p.text for p in self.doc.paragraphs):
            self.blocks.append('Восстановленный документ: нужен отдельный полный цикл проверки вне первой версии.')
        if any(re.search(r'\[[А-ЯЁA-Z][А-ЯЁA-Z0-9_]*_\d+\]', p.text) for p in self.doc.paragraphs):
            self.blocks.append('Документ уже содержит токены. Откройте исходный DOCX, чтобы не смешивать соответствия.')

    def add_manual(self, value: str):
        if not value or not value.strip():
            raise DocumentError('Укажите точный непустой фрагмент.')
        added = 0
        for p in self.doc.paragraphs:
            start = 0
            while (pos := p.text.find(value, start)) >= 0:
                end = pos + len(value)
                start = end
                overlaps = [f for f in self.findings if f.part == p.part and f.paragraph == p.index
                            and pos < f.end and end > f.start]
                if overlaps:
                    continue
                self.findings.append(Finding(uuid.uuid4().hex, p.part, p.index, pos, end,
                                             value, 'ФРАГМЕНТ', 'MANUAL'))
                added += 1
        if not added:
            raise DocumentError('Новых совпадений нет: проверьте написание и пересечения с существующими находками.')
        self.findings.sort(key=lambda f: (f.part, f.paragraph, f.start))
        return added

    def plan(self, vault: Vault):
        # Generate deterministic preview against the current saved case state.
        shadow = deepcopy(vault)
        replacements = {}
        entities = {}
        groups = {}
        for f in self.findings:
            if f.decision == 'replace':
                e = groups.get(f.group) if f.group else None
                if e is None:
                    e = shadow.entity(f)
                    if f.group:
                        groups[f.group] = e
                f.token = e['token']
                entities[f.id] = e
                replacements.setdefault((f.part, f.paragraph), []).append((f.start, f.end, e['token']))
            else:
                f.token = ''
        return shadow, replacements, entities

    def preview(self, vault):
        _, edits, _ = self.plan(vault)
        result = []
        for p in self.doc.paragraphs:
            text = p.text
            for a, b, token in sorted(edits.get((p.part, p.index), []), reverse=True):
                text = text[:a] + token + text[b:]
            result.append(text)
        return result

    def group_selected(self, ids):
        selected = [f for f in self.findings if f.id in ids]
        if len(selected) < 2:
            raise DocumentError('Выберите минимум два упоминания одной сущности.')
        group = uuid.uuid4().hex
        kind = 'ЛИЦО' if any(f.kind == 'ЛИЦО' for f in selected) else selected[0].kind
        for f in selected:
            f.group = group
            f.kind = kind
            f.decision = 'pending'

    def split_selected(self, ids):
        for f in self.findings:
            if f.id in ids:
                if f.kind in {'ТЕЛЕФОН', 'ПАСПОРТ', 'СНИЛС', 'ИНН', 'СЧЕТ', 'EMAIL'}:
                    raise DocumentError('Автосвязь реквизитов отключается через ручной фрагмент, а не разделение имен.')
                f.group = ''
                f.decision = 'pending'

    def export(self, vault: Vault, destination: Path, *, reviewed=False):
        if self.blocks:
            raise DocumentError('Экспорт заблокирован. Есть неподдерживаемые части или особый режим сведений.')
        if any(f.decision not in {'replace', 'keep'} for f in self.findings):
            raise DocumentError('Примите решение по каждой находке.')
        if not reviewed:
            raise DocumentError('Подтвердите ручную проверку всего текста, оформления и остаточных рисков.')
        target = Path(destination).resolve()
        if target.suffix.lower() != '.docx':
            raise DocumentError('Выходной файл должен иметь расширение .docx.')
        # A separate directory, not merely a different filename.
        if target == self.path or target.parent == self.path.parent:
            raise DocumentError('Сохраните копию в отдельную папку, не рядом с оригиналом.')
        if target.parent == vault.path.parent or vault.path.parent in target.parents:
            raise DocumentError('Папка экспорта должна быть отдельно от приватного хранилища.')
        if target.exists():
            raise DocumentError('Файл уже существует. Выберите новое имя.')
        shadow, edits, entities = self.plan(vault)
        output = self.doc.render(edits)
        checked = Docx(output)
        # Scan the serialized final package, including attributes and service parts.
        surfaces = []
        for root in checked.roots.values():
            surfaces.extend(''.join(root.itertext()).split('\x00'))
            surfaces.extend(value for el in root.iter() if isinstance(el.tag, str) for value in el.attrib.values())
        for f in self.findings:
            if f.decision == 'replace' and any(f.original in s for s in surfaces):
                raise DocumentError('Повторная проверка нашла скрываемое значение в итоговом файле. Экспорт заблокирован.')
        document_id = uuid.uuid4().hex
        version_id = uuid.uuid4().hex
        source_hash = digest(self.doc.original)
        # Exact binary source is encrypted together with all mappings. It is never
        # copied into the external export directory or sent to a remote service.
        shadow.data['documents'].append({'id': document_id, 'sha256': source_hash,
                                         'source': base64.b64encode(self.doc.original).decode('ascii'),
                                         'created_at': now()})
        records = []
        for f in self.findings:
            record = {**asdict(f), 'record_id': uuid.uuid4().hex,
                      'document_id': document_id, 'source_hash': source_hash,
                      'version_id': version_id, 'decided_at': now(),
                      'action': 'TOKENIZE' if f.decision == 'replace' else 'KEEP_AFTER_REVIEW'}
            records.append(record)
            if f.id in entities:
                entities[f.id]['occurrences'].append(record)
        # Every changed package part has an immutable source reference, including
        # properties, removed editing IDs and XML serialization changes.
        for part, original in self.doc.entries.items():
            if checked.entries.get(part) != original:
                records.append({'record_id': uuid.uuid4().hex, 'token': '[ОБЪЕКТ_' + uuid.uuid4().hex + ']',
                                'action': 'VAULT_STRIP' if part not in checked.entries else 'SOURCE_SNAPSHOT',
                                'source_part': part, 'document_id': document_id,
                                'source_hash': source_hash, 'original_part_sha256': digest(original),
                                'restore_from': 'encrypted_original_package'})
        shadow.data['history'].append({'version_id': version_id, 'document_id': document_id,
                                       'created_at': now(), 'rules_version': 'baseline-0.1',
                                       'output_sha256': digest(output), 'records': records,
                                       'manual_full_review': True})
        # If the vault write fails, no external file exists. If the export fails,
        # the recorded source remains recoverable and a retry is possible.
        shadow.save()
        vault.data = shadow.data
        vault.saved_hash = shadow.saved_hash
        atomic_write(target, output)
        return {'replacements': sum(f.decision == 'replace' for f in self.findings),
                'kept': sum(f.decision == 'keep' for f in self.findings),
                'document_id': document_id, 'output_sha256': digest(output)}

    @staticmethod
    def restore_original(vault, document_id, destination):
        target = Path(destination).resolve()
        if target.exists():
            raise VaultError('Восстановление разрешено только в новый файл.')
        if target.suffix.lower() != '.docx' or not target.stem.startswith('КОНФИДЕНЦИАЛЬНО_'):
            raise VaultError('Для точной копии оригинала используйте имя КОНФИДЕНЦИАЛЬНО_….docx.')
        atomic_write(target, vault.source(document_id))

    @staticmethod
    def restore_selected(vault, document_id, tokens, destination):
        from .docx import W, dump
        from io import BytesIO
        from zipfile import ZipFile, ZIP_DEFLATED
        history = next(h for h in reversed(vault.data['history']) if h['document_id'] == document_id)
        records = [r for r in history['records'] if r.get('action') == 'TOKENIZE']
        available = {r['token'] for r in records}
        if not tokens or not set(tokens) <= available:
            raise VaultError('Выбранные токены отсутствуют в этой версии документа.')
        target = Path(destination).resolve()
        if target.exists() or target.suffix.lower() != '.docx' or not target.stem.startswith('КОНФИДЕНЦИАЛЬНО_'):
            raise VaultError('Выберите новый файл КОНФИДЕНЦИАЛЬНО_….docx.')
        doc = Docx(vault.source(document_id))
        edits = {}
        for r in records:
            if r['token'] not in tokens:
                edits.setdefault((r['part'], r['paragraph']), []).append((r['start'], r['end'], r['token']))
        restored = Docx(doc.render(edits))
        body = restored.roots['word/document.xml'].find(f'{{{W}}}body')
        label = ET.Element(f'{{{W}}}p')
        run = ET.SubElement(label, f'{{{W}}}r')
        ET.SubElement(run, f'{{{W}}}t').text = 'КОНФИДЕНЦИАЛЬНО: ВОССТАНОВЛЕННЫЕ ДАННЫЕ'
        body.insert(0, label)
        restored.entries['word/document.xml'] = dump(restored.roots['word/document.xml'])
        output = BytesIO()
        with ZipFile(output, 'w', ZIP_DEFLATED) as z:
            for name, data in restored.entries.items():
                z.writestr(name, data)
        atomic_write(target, output.getvalue())
