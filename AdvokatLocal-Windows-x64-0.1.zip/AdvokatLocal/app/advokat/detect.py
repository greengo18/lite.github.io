"""Baseline detectors. A review assistant, not a complete implementation of 89 rules."""
from dataclasses import dataclass
import re
import uuid


@dataclass
class Finding:
    id: str
    part: str
    paragraph: int
    start: int
    end: int
    original: str
    kind: str
    rule: str
    decision: str = 'pending'
    token: str = ''
    group: str = ''


# Context is mandatory for ambiguous numbers; legal citations and sums are untouched.
PATTERNS = [
    ('ПАСПОРТ', 'PD-04', r'(?i:паспорт(?:а|ом)?\s*(?:серия\s*)?)(?P<value>\d{2}\s?\d{2}\s*(?:№\s*)?\d{6})(?!\d)'),
    ('СНИЛС', 'PD-05', r'(?i:СНИЛС\s*[:№]?\s*)(?P<value>\d{3}[- ]?\d{3}[- ]?\d{3}\s?\d{2})(?!\d)'),
    ('ИНН', 'PD-05', r'(?i:ИНН\s*[:№]?\s*)(?P<value>\d{12})(?!\d)'),
    ('СЧЕТ', 'PD-13', r'(?i:(?:сч[её]т(?:а|у|ом)?|р/с|л/с)\s*[:№]?\s*)(?P<value>\d{20})(?!\d)'),
    ('ТЕЛЕФОН', 'PD-08', r'(?<![\w\d])(?P<value>(?:\+7|8)[ (.-]*\d{3}[ ).-]*\d{3}[ .-]*\d{2}[ .-]*\d{2})(?!\d)'),
    ('EMAIL', 'PD-08', r'(?<![\w.+-])(?P<value>[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})(?![\w-])'),
    # Full three-part names only. Initials, inflections and identity resolution require manual review.
    ('ЛИЦО', 'PD-01', r'(?<![А-Яа-яЁё])(?P<value>[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё]*(?:вич|вна|вича|вичу|вичем|виче|вны|вне|вну|вной))(?![А-Яа-яЁё])'),
]
COMPILED = [(kind, rule, re.compile(pattern)) for kind, rule, pattern in PATTERNS]
HARD = re.compile(r'(?i)(?:государственн\w*\s+тайн\w*|совершенно\s+секретно|защищаем\w*\s+свидетел\w*|конфиденциальн\w*\s+источник\w*|секретн\w*\s+сотрудник\w*)')


def detect(paragraphs):
    found = []
    for p in paragraphs:
        ranges = []
        for kind, rule, pattern in COMPILED:
            for m in pattern.finditer(p.text):
                start, end = m.span('value')
                if any(start < b and end > a for a, b in ranges):
                    continue
                ranges.append((start, end))
                found.append(Finding(uuid.uuid4().hex, p.part, p.index, start, end,
                                     p.text[start:end], kind, rule))
    return sorted(found, key=lambda f: (f.part, f.paragraph, f.start))


def normalized(kind, value):
    if kind in {'ТЕЛЕФОН', 'ПАСПОРТ', 'СНИЛС', 'ИНН', 'СЧЕТ'}:
        result = re.sub(r'\D', '', value)
        if kind == 'ТЕЛЕФОН' and len(result) == 11:
            result = '7' + result[1:]
        return result
    # Do not infer that equal names are necessarily the same person.
    return value
