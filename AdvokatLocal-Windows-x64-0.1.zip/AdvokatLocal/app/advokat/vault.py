"""Encrypted case store. Passwords and plaintext originals are never persisted."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile
import uuid

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b'ADVOKAT-CASE-1\x00'


class VaultError(ValueError):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path: Path, data: bytes):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.advokat-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


class Vault:
    def __init__(self, path: Path, password: str, *, create=False):
        self.path = Path(path).resolve()
        if len(password) < 12:
            raise VaultError('Нужна парольная фраза длиной не менее 12 символов.')
        if create and self.path.exists():
            raise VaultError('Хранилище уже существует. Откройте его, чтобы сохранить соответствия.')
        if not create and not self.path.is_file():
            raise VaultError('Хранилище не найдено.')
        if create:
            self.salt = os.urandom(16)
            blob = None
        else:
            blob = self.path.read_bytes()
            if not blob.startswith(MAGIC) or len(blob) < len(MAGIC) + 44:
                raise VaultError('Неподдерживаемый формат хранилища.')
            self.salt = blob[len(MAGIC):len(MAGIC) + 16]
        self.saved_hash = digest(blob) if blob is not None else None
        self.key = Scrypt(salt=self.salt, length=32, n=2**15, r=8, p=1).derive(password.encode('utf-8'))
        if create:
            self.data = {'version': 1, 'case_id': uuid.uuid4().hex, 'entities': [], 'documents': [], 'history': []}
            self.save()
        else:
            at = len(MAGIC) + 16
            try:
                raw = AESGCM(self.key).decrypt(blob[at:at + 12], blob[at + 12:], MAGIC + self.salt)
                self.data = json.loads(raw)
                if self.data.get('version') != 1:
                    raise VaultError('Неподдерживаемая версия хранилища.')
            except (InvalidTag, ValueError, KeyError) as e:
                raise VaultError('Неверная парольная фраза или хранилище повреждено.') from e

    def save(self):
        if self.saved_hash is None:
            if self.path.exists():
                raise VaultError('Файл дела уже создан другим процессом. Откройте его заново.')
        elif not self.path.exists() or digest(self.path.read_bytes()) != self.saved_hash:
            raise VaultError('Дело изменилось вне программы. Откройте его заново перед сохранением.')
        nonce = os.urandom(12)
        raw = json.dumps(self.data, ensure_ascii=False).encode('utf-8')
        encrypted = AESGCM(self.key).encrypt(nonce, raw, MAGIC + self.salt)
        # Verify authentication before replacing the previous encrypted file.
        if AESGCM(self.key).decrypt(nonce, encrypted, MAGIC + self.salt) != raw:
            raise VaultError('Проверка шифрования не пройдена.')
        blob = MAGIC + self.salt + nonce + encrypted
        atomic_write(self.path, blob)
        self.saved_hash = digest(blob)

    def source(self, document_id):
        doc = next(d for d in self.data['documents'] if d['id'] == document_id)
        source = base64.b64decode(doc['source'], validate=True)
        if digest(source) != doc['sha256']:
            raise VaultError('Контрольная сумма оригинала не совпадает.')
        return source

    def entity(self, finding):
        from .detect import normalized
        norm = normalized(finding.kind, finding.original)
        # Automatic linking only for unambiguous typed numeric/contact identifiers.
        linkable = finding.kind in {'ТЕЛЕФОН', 'ПАСПОРТ', 'СНИЛС', 'ИНН', 'СЧЕТ', 'EMAIL'}
        if linkable:
            for e in self.data['entities']:
                if e['type'] == finding.kind and e['normalized_value'] == norm:
                    return e
        number = 1 + sum(e['type'] == finding.kind for e in self.data['entities'])
        e = {'entity_id': uuid.uuid4().hex, 'case_id': self.data['case_id'],
             'token': f'[{finding.kind}_{number:03d}]', 'type': finding.kind,
             'rule_ids': [finding.rule], 'normalized_value': norm,
             'original_value': finding.original, 'occurrences': [], 'created_at': now()}
        self.data['entities'].append(e)
        return e

    def decode(self, text):
        import re
        entities = {e['token']: e for e in self.data['entities']}
        warnings = []
        def replace(m):
            e = entities.get(m.group())
            if not e:
                warnings.append('Неизвестный токен: ' + m.group())
                return m.group()
            variants = {o['original'] for o in e['occurrences']}
            if len(variants) != 1:
                warnings.append('Нужно выбрать исходную форму вручную: ' + m.group())
                return m.group()
            return next(iter(variants))
        result = re.sub(r'\[[А-ЯЁA-Z][А-ЯЁA-Z0-9_]*_\d+\]', replace, text)
        return 'КОНФИДЕНЦИАЛЬНО: ВОССТАНОВЛЕННЫЕ ДАННЫЕ\n\n' + result, sorted(set(warnings))

    def backup(self, destination):
        destination = Path(destination).resolve()
        if destination == self.path or destination.exists():
            raise VaultError('Выберите новый файл резервной копии.')
        blob = self.path.read_bytes()
        at = len(MAGIC) + 16
        AESGCM(self.key).decrypt(blob[at:at + 12], blob[at + 12:], MAGIC + self.salt)
        atomic_write(destination, blob)
