"""Offline desktop UI; no server, webview, analytics or updater."""
from __future__ import annotations

import os
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from .docx import DocumentError
from .service import Session
from .vault import Vault, VaultError


class App:
    def __init__(self, root):
        self.root = root
        self.vault = None
        self.session = None
        self.revealed = tk.BooleanVar(value=False)
        self.reviewed = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='Создайте или откройте зашифрованное дело. Затем выберите документ DOCX.')
        root.title('Адвокат · локальная проверка DOCX · 0.1')
        root.geometry('1280x850')
        root.minsize(960, 680)
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('TButton', padding=(10, 7))
        style.configure('Treeview', rowheight=27)
        top = ttk.Frame(root, padding=12)
        top.pack(fill='x')
        ttk.Label(top, text='Адвокат', font=('Segoe UI', 20, 'bold')).pack(side='left')
        ttk.Label(top, text='  Локальное обезличивание Word', font=('Segoe UI', 12)).pack(side='left')
        ttk.Label(top, text='DOCX · без облачных сервисов').pack(side='right')
        toolbar = ttk.Frame(root, padding=(12, 0, 12, 8))
        toolbar.pack(fill='x')
        for title, command in [('Новое дело', self.new_case), ('Открыть дело', self.open_case),
                               ('Открыть DOCX', self.open_document), ('Реестр / восстановление', self.register),
                               ('Расшифровать ответ', self.decoder), ('Резервная копия', self.backup)]:
            ttk.Button(toolbar, text=title, command=lambda c=command: self.guard(c)).pack(side='left', padx=(0, 6))
        ttk.Label(root, text='Первая версия: базовые детекторы и ручная проверка. Адреса, инициалы, скрытый смысл и тайны требуют вашей оценки.',
                  foreground='#8a3d00', padding=(12, 6)).pack(fill='x')
        ttk.Checkbutton(root, text='Показать конфиденциальные фрагменты на экране', variable=self.revealed,
                        command=self.refresh).pack(anchor='w', padx=12)
        self.banner = ttk.Label(root, textvariable=self.status, padding=12, wraplength=1180)
        self.banner.pack(fill='x')
        body = ttk.Panedwindow(root, orient='vertical')
        body.pack(fill='both', expand=True, padx=12)
        finding_frame = ttk.Frame(body)
        columns = ('kind', 'original', 'token', 'where', 'decision')
        self.table = ttk.Treeview(finding_frame, columns=columns, show='headings', selectmode='extended', height=7)
        for col, label, width in zip(columns, ['Категория / правило', 'Исходный фрагмент', 'Замена', 'Местоположение', 'Решение'], [170, 300, 160, 280, 130]):
            self.table.heading(col, text=label)
            self.table.column(col, width=width, minwidth=70)
        scroll = ttk.Scrollbar(finding_frame, orient='vertical', command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        self.table.pack(fill='both', expand=True)
        self.table.bind('<<TreeviewSelect>>', self.show_selection)
        body.add(finding_frame, weight=1)
        previews = ttk.Panedwindow(body, orient='horizontal')
        self.original = self.text_panel(previews, 'Исходный текст (оформление смотрите в Word)')
        self.processed = self.text_panel(previews, 'Предпросмотр замен (не визуальная копия страниц)')
        body.add(previews, weight=2)
        actions = ttk.Frame(root, padding=12)
        actions.pack(fill='x')
        for text, decision in [('Заменить выбранные', 'replace'), ('Оставить выбранные', 'keep'), ('Вернуть на проверку', 'pending')]:
            ttk.Button(actions, text=text, command=lambda d=decision: self.guard(lambda: self.decide(d))).pack(side='left', padx=(0, 6))
        ttk.Button(actions, text='Добавить точный фрагмент…', command=lambda: self.guard(self.add_manual)).pack(side='left')
        footer = ttk.Frame(root, padding=(12, 0, 12, 12))
        footer.pack(fill='x')
        ttk.Checkbutton(footer, variable=self.reviewed, text='Я проверил весь текст и решения; понимаю, что детекторы могут пропустить сведения.',
                        command=self.update_export).pack(side='left')
        self.export_button = ttk.Button(footer, text='Сохранить отдельную копию DOCX', command=lambda: self.guard(self.export), state='disabled')
        self.export_button.pack(side='right')
        menu = tk.Menu(self.table, tearoff=False)
        menu.add_command(label='Объединить выбранные упоминания', command=lambda: self.guard(self.merge))
        menu.add_command(label='Разделить выбранные упоминания', command=lambda: self.guard(self.split))
        self.table.bind('<Button-3>', lambda e: menu.tk_popup(e.x_root, e.y_root))
        root.protocol('WM_DELETE_WINDOW', self.close)

    def text_panel(self, parent, label):
        frame = ttk.Frame(parent)
        ttk.Label(frame, text=label, padding=6).pack(anchor='w')
        text = tk.Text(frame, wrap='word', font=('Segoe UI', 11), state='disabled', padx=10, pady=10)
        scroll = ttk.Scrollbar(frame, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        text.pack(fill='both', expand=True)
        text.tag_configure('selected', background='#fff0b3')
        parent.add(frame, weight=1)
        return text

    def guard(self, operation):
        try:
            operation()
        except (DocumentError, VaultError, OSError, ValueError) as e:
            messagebox.showerror('Операция не выполнена', str(e), parent=self.root)
        except Exception:
            # Do not write plaintext input or tracebacks into files/crash reports.
            messagebox.showerror('Операция не выполнена', 'Неожиданная ошибка. Файл не считается успешно проверенным.', parent=self.root)

    def require_vault(self):
        if self.vault is None:
            raise VaultError('Сначала создайте или откройте дело.')

    def private_dir(self):
        base = Path(os.environ.get('LOCALAPPDATA', Path.home() / '.local' / 'share')) / 'AdvokatLocal' / 'cases'
        base.mkdir(parents=True, exist_ok=True)
        return base

    def new_case(self):
        path = filedialog.asksaveasfilename(parent=self.root, title='Новое зашифрованное дело (не папка облачной синхронизации)',
                                           initialdir=self.private_dir(), initialfile='case.enc', defaultextension='.enc', filetypes=[('Зашифрованное дело', '*.enc')])
        if not path:
            return
        password = simpledialog.askstring('Парольная фраза', 'Не менее 12 символов. При потере пароля восстановление невозможно.', show='*', parent=self.root)
        if password is None:
            return
        confirm = simpledialog.askstring('Повторите парольную фразу', 'Введите ту же парольную фразу.', show='*', parent=self.root)
        if confirm is None:
            return
        if password != confirm:
            raise VaultError('Парольные фразы не совпадают.')
        self.vault = Vault(Path(path), password, create=True)
        self.reset_session()
        self.status.set('Дело создано. Откройте DOCX. Не храните хранилище и экспорт в одной папке.')

    def open_case(self):
        path = filedialog.askopenfilename(parent=self.root, title='Открыть зашифрованное дело', initialdir=self.private_dir(), filetypes=[('Зашифрованное дело', '*.enc')])
        if not path:
            return
        password = simpledialog.askstring('Открыть дело', 'Парольная фраза:', show='*', parent=self.root)
        if password is None:
            return
        self.vault = Vault(Path(path), password)
        self.reset_session()
        self.status.set('Дело открыто. Можно открыть DOCX или просмотреть приватный реестр.')

    def reset_session(self):
        self.session = None
        self.revealed.set(False)
        self.reviewed.set(False)
        self.refresh()

    def open_document(self):
        self.require_vault()
        path = filedialog.askopenfilename(parent=self.root, title='Исходный документ Word', filetypes=[('Word DOCX', '*.docx')])
        if not path:
            return
        self.session = None
        self.reviewed.set(False)
        self.refresh()
        self.session = Session(Path(path))
        self.refresh()

    def put(self, widget, text):
        widget.configure(state='normal')
        widget.delete('1.0', 'end')
        widget.insert('1.0', text)
        widget.configure(state='disabled')

    def refresh(self):
        selected = self.table.selection()
        self.table.delete(*self.table.get_children())
        if self.session is None:
            self.put(self.original, '')
            self.put(self.processed, '')
            self.update_export()
            return
        preview = self.session.preview(self.vault)
        decisions = {'pending': 'Не решено', 'replace': 'Заменить', 'keep': 'Оставить'}
        for f in self.session.findings:
            self.table.insert('', 'end', iid=f.id, values=(f'{f.kind} · {f.rule}', f.original if self.revealed.get() else '••••••',
                                                         f.token or '—', f'{f.part} · абз. {f.paragraph + 1}', decisions[f.decision]))
        self.table.selection_set([item for item in selected if self.table.exists(item)])
        if self.revealed.get():
            def assemble(texts):
                return '\n\n'.join(f'[{p.part} · абз. {p.index + 1}]\n{text}' for p, text in zip(self.session.doc.paragraphs, texts))
            self.put(self.original, assemble([p.text for p in self.session.doc.paragraphs]))
            self.put(self.processed, assemble(preview))
        else:
            self.put(self.original, 'Текст скрыт. Включите показ конфиденциальных фрагментов для проверки.')
            self.put(self.processed, 'Предпросмотр скрыт.')
        pending = sum(f.decision == 'pending' for f in self.session.findings)
        if self.session.blocks:
            self.status.set('ЭКСПОРТ ЗАБЛОКИРОВАН: ' + '; '.join(self.session.blocks[:6]))
        else:
            self.status.set(f'Найдено фрагментов: {len(self.session.findings)}. Не решено: {pending}. '
                            'Проверьте текст полностью, добавьте пропущенные имена, адреса и другие сведения вручную.')
        self.update_export()

    def update_export(self):
        ready = bool(self.session and self.vault and not self.session.blocks and self.reviewed.get()
                     and self.revealed.get() and all(f.decision in {'replace', 'keep'} for f in self.session.findings))
        self.export_button.configure(state='normal' if ready else 'disabled')

    def show_selection(self, event=None):
        if not self.session or not self.revealed.get() or not self.table.selection():
            return
        f = next((f for f in self.session.findings if f.id == self.table.selection()[0]), None)
        if f:
            marker = f'[{f.part} · абз. {f.paragraph + 1}]'
            pos = self.original.search(marker, '1.0', stopindex='end')
            if pos:
                self.original.tag_remove('selected', '1.0', 'end')
                self.original.tag_add('selected', pos, f'{pos} lineend')
                self.original.see(pos)

    def decide(self, decision):
        if not self.session:
            return
        if not self.revealed.get():
            raise DocumentError('Сначала включите показ фрагментов и проверьте их.')
        selected = set(self.table.selection())
        for f in self.session.findings:
            if f.id in selected:
                f.decision = decision
        self.reviewed.set(False)
        self.refresh()

    def add_manual(self):
        if not self.session:
            raise DocumentError('Сначала откройте DOCX.')
        value = simpledialog.askstring('Ручное добавление', 'Точный фрагмент для поиска во всем документе (например, адрес или фамилия с инициалами):', parent=self.root)
        if value is not None:
            self.session.add_manual(value)
            self.reviewed.set(False)
            self.refresh()

    def merge(self):
        if not self.session or not self.revealed.get():
            raise DocumentError('Откройте документ и включите показ фрагментов.')
        if messagebox.askokcancel('Одна сущность?', 'Объединить выбранные упоминания под одним токеном? Подтвердите, что они относятся к одной сущности. Исходные формы сохранятся отдельно.', parent=self.root):
            self.session.group_selected(set(self.table.selection()))
            self.reviewed.set(False)
            self.refresh()

    def split(self):
        if self.session:
            self.session.split_selected(set(self.table.selection()))
            self.reviewed.set(False)
            self.refresh()

    def export(self):
        self.require_vault()
        if not self.session:
            return
        target = filedialog.asksaveasfilename(parent=self.root, title='Отдельная папка для обработанной копии', initialfile='document_clean.docx',
                                             defaultextension='.docx', filetypes=[('Word DOCX', '*.docx')])
        if not target:
            return
        if not messagebox.askokcancel('Перед сохранением', 'Это экспериментальная первая версия.\n\n'
                                      'Она не определяет допустимость раскрытия адвокатской и иной тайны. '
                                      'После сохранения откройте копию в Word и проверьте оформление. '
                                      'Ничего не отправляется автоматически.\n\nСохранить?', parent=self.root):
            return
        result = self.session.export(self.vault, Path(target), reviewed=self.reviewed.get())
        self.reviewed.set(False)
        self.refresh()
        messagebox.showinfo('Копия сохранена', f"Замен: {result['replacements']}.\nОригинал и соответствия сохранены в зашифрованном деле.\n"
                                'Откройте обработанную копию в Word и проверьте страницы и переносы.', parent=self.root)

    def register(self):
        self.require_vault()
        win = tk.Toplevel(self.root)
        win.title('Приватный реестр · только локально')
        win.geometry('1000x650')
        ttk.Label(win, text='Конфиденциально. Значения скрыты; реестр не включается в обработанный DOCX.', padding=10).pack(fill='x')
        show = tk.BooleanVar(value=False)
        search = tk.StringVar()
        ttk.Entry(win, textvariable=search).pack(fill='x', padx=10)
        tree = ttk.Treeview(win, columns=('token', 'kind', 'original', 'count'), show='headings')
        for col, title in [('token', 'Токен'), ('kind', 'Тип'), ('original', 'Исходное значение'), ('count', 'Упоминаний')]:
            tree.heading(col, text=title, command=lambda c=col: sort(c))
        tree.pack(fill='both', expand=True, padx=10)
        details = tk.Text(win, height=6, wrap='word', state='disabled')
        details.pack(fill='x', padx=10)
        def sort(col):
            for index, (_, item) in enumerate(sorted((tree.set(i, col), i) for i in tree.get_children())):
                tree.move(item, '', index)
        def fill(*args):
            tree.delete(*tree.get_children())
            query = search.get().casefold()
            for e in self.vault.data['entities']:
                if query and query not in e['token'].casefold() and (not show.get() or query not in e['original_value'].casefold()):
                    continue
                tree.insert('', 'end', iid=e['entity_id'], values=(e['token'], e['type'], e['original_value'] if show.get() else '••••••', len(e['occurrences'])))
            self.put(details, '')
        def selection(event):
            if not show.get() or not tree.selection():
                return
            e = next(e for e in self.vault.data['entities'] if e['entity_id'] == tree.selection()[0])
            self.put(details, '\n'.join(f"{o['original']} — {o['part']}, абз. {o['paragraph'] + 1}; документ {o['document_id'][:8]}" for o in e['occurrences']))
        tree.bind('<<TreeviewSelect>>', selection)
        ttk.Checkbutton(win, text='Показать исходные значения', variable=show, command=fill).pack(anchor='w', padx=10)
        search.trace_add('write', fill)
        docs = self.vault.data['documents']
        chosen = tk.StringVar()
        ttk.Label(win, text='Точное восстановление оригинала (выберите документ):').pack(anchor='w', padx=10)
        ttk.Combobox(win, textvariable=chosen, values=[d['id'] for d in docs], state='readonly').pack(fill='x', padx=10)
        def restore():
            if not chosen.get():
                raise VaultError('Выберите документ.')
            dest = filedialog.asksaveasfilename(parent=win, initialfile='КОНФИДЕНЦИАЛЬНО_оригинал.docx', defaultextension='.docx', filetypes=[('Word DOCX', '*.docx')])
            if dest:
                Session.restore_original(self.vault, chosen.get(), dest)
                messagebox.showinfo('Оригинал восстановлен', 'Создана точная конфиденциальная копия оригинала. Не передавайте ее как обезличенную.', parent=win)
        ttk.Button(win, text='Восстановить оригинал в новый файл', command=lambda: self.guard(restore)).pack(pady=10)
        def restore_selected():
            if not chosen.get():
                raise VaultError('Выберите документ.')
            tokens = [e['token'] for e in self.vault.data['entities'] if e['entity_id'] in tree.selection()]
            if not tokens:
                raise VaultError('Выберите токены в таблице (Ctrl для нескольких).')
            dest = filedialog.asksaveasfilename(parent=win, initialfile='КОНФИДЕНЦИАЛЬНО_выбранные.docx', defaultextension='.docx', filetypes=[('Word DOCX', '*.docx')])
            if dest:
                Session.restore_selected(self.vault, chosen.get(), tokens, dest)
                messagebox.showinfo('Восстановлено', 'Выбранные значения восстановлены в отдельной конфиденциальной копии.', parent=win)
        ttk.Button(win, text='Восстановить выбранные токены в новом DOCX', command=lambda: self.guard(restore_selected)).pack(pady=(0, 10))
        fill()

    def decoder(self):
        self.require_vault()
        win = tk.Toplevel(self.root)
        win.title('Локальная расшифровка · конфиденциально')
        win.geometry('950x650')
        ttk.Label(win, text='Вставьте ответ с токенами из текущего дела. Сетевых обращений нет.', padding=10).pack()
        inp = tk.Text(win, height=10, wrap='word')
        inp.pack(fill='both', expand=True, padx=10)
        out = tk.Text(win, height=10, wrap='word', state='disabled')
        out.pack(fill='both', expand=True, padx=10)
        def decode():
            result, warnings = self.vault.decode(inp.get('1.0', 'end-1c'))
            self.put(out, result + ('\n\nТРЕБУЕТ ПРОВЕРКИ:\n' + '\n'.join(warnings) if warnings else ''))
        ttk.Button(win, text='Расшифровать локально', command=lambda: self.guard(decode)).pack(pady=10)

    def backup(self):
        self.require_vault()
        path = filedialog.asksaveasfilename(parent=self.root, initialfile='case_backup.enc', defaultextension='.enc', filetypes=[('Зашифрованная копия', '*.enc')])
        if path:
            self.vault.backup(path)
            messagebox.showinfo('Резервная копия', 'Зашифрованная копия сохранена; проверка целостности пройдена. Для открытия нужна та же парольная фраза.', parent=self.root)

    def close(self):
        if self.session and not messagebox.askokcancel('Закрыть программу?', 'Несохраненные решения по открытому документу будут потеряны.', parent=self.root):
            return
        self.session = None
        self.vault = None
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()
