"""Run synthetic tests only; never opens the user's documents or case storage."""
from pathlib import Path
import sys
import unittest

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'app'))
print('AdvokatLocal: local self-test using synthetic documents only.', flush=True)
try:
    suite = unittest.defaultTestLoader.discover(str(BASE / 'tests'))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
except Exception:
    print('STARTUP ERROR: keep the entire extracted folder together. Windows 10/11 x64 is required.')
    raise SystemExit(1)
raise SystemExit(0 if result.wasSuccessful() else 1)
